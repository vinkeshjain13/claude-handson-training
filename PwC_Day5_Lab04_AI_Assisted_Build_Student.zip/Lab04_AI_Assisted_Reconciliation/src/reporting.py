"""Milestone 3: generate CSV/JSON reconciliation evidence."""
def save_reports(rows: list[dict], directory='reports') -> dict:
    """Create reports/reconciliation.csv, exceptions.json, summary.json.
    Return deterministic summary. JSON must be human readable; no invented rows.
    """
    raise NotImplementedError('Milestone 3: implement reports')
