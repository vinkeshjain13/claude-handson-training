"""Milestone 1: CSV loader. Implement using Claude Code, then review the diff."""
from pathlib import Path
from decimal import Decimal
FIELDS = {'transaction_id','amount','settlement_date','currency','account_ref'}

def load_transactions(path: str | Path) -> list[dict]:
    """Return validated rows with Decimal amounts.

    Requirements:
    - UTF-8-SIG CSV; required headers; clear file/line errors.
    - Reject empty IDs/account refs, non-INR, non-ISO dates, NaN/Infinity,
      zero/negative amounts and >2 decimal places.
    - Do NOT convert money to float.
    """
    raise NotImplementedError('Milestone 1: build validated CSV loading')
