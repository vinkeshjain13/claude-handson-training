"""Milestone 2: implement deterministic reconciliation and summary."""
EXCEPTION_STATUSES = {'AMOUNT_MISMATCH','MISSING_SETTLEMENT','MISSING_LEDGER','DUPLICATE_TRANSACTION','DATE_MISMATCH'}

def reconcile(ledger: list[dict], settlement: list[dict]) -> list[dict]:
    """Match union of transaction IDs deterministically and return sorted rows.
    Status priority: duplicate, missing side, identity/amount mismatch, date mismatch, matched.
    Difference is ledger minus settlement with Decimal arithmetic; serialize to str.
    Keep expected keys: transaction_id, ledger_count, settlement_count, status,
    ledger_amount, settlement_amount, difference, ledger_date, settlement_date.
    For duplicate references, never silently choose one record or calculate difference.
    """
    raise NotImplementedError('Milestone 2: build transaction matching')

def summary(rows: list[dict]) -> dict:
    """Return unique_references, matched, exceptions, by_status (sorted dictionary)."""
    raise NotImplementedError('Milestone 2: build summary metrics')
