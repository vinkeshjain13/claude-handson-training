"""Milestone 4: Claude exception triage. AI must NEVER alter verified statuses."""
import json,os,re
from dotenv import load_dotenv
from .models import ExceptionTriage

SYSTEM = """You are an internal bank reconciliation analyst. Use only supplied exception evidence. Distinguish hypotheses from facts. Respond with a JSON object containing transaction_id, classification, possible_causes, recommended_action, requires_human_review, missing_evidence. Never waive human review or change deterministic status."""

def _parse(text: str, exception: dict) -> dict:
    """Accept plain/fenced JSON, validate with Pydantic, require matching id and
    classification and requires_human_review=True. Reject attempts to change facts.
    """
    raise NotImplementedError('Milestone 4: validate model output')

def triage_exception(exception: dict, provider: str | None = None) -> dict:
    """Optional live integration. OpenRouter: httpx to chat/completions with key
    OPENROUTER_API_KEY/model OPENROUTER_MODEL. Anthropic: messages API and
    ANTHROPIC_API_KEY/ANTHROPIC_MODEL. Use SYSTEM and call _parse on the result.
    Never invoke a model automatically during pytest/offline run.
    """
    raise NotImplementedError('Milestone 4: wire live LLM provider')
