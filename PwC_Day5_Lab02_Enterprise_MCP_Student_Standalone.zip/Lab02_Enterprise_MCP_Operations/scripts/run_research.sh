#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ -f .env ]]; then set -a; source .env; set +a; fi
exec "$(pwd)/.venv/bin/python" -m mcp_servers.research
